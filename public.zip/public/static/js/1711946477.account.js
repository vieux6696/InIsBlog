const t="/static/images/1711946477.account.svg";export{t as default};
