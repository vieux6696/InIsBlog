const a="/static/images/1711946477.add.svg";export{a as default};
