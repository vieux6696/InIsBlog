const a="/static/images/1711946477.alipay.svg";export{a as default};
