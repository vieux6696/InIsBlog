const a="/static/images/1711946477.aliyun.svg";export{a as default};
