const a="/static/images/1711946477.all.svg";export{a as default};
