const t="/static/images/1711946477.article.svg";export{t as default};
