const a="/static/images/1711946477.banner.svg";export{a as default};
