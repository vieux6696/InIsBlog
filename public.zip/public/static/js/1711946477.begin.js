const s="/static/images/1711946477.begin.svg";export{s as default};
