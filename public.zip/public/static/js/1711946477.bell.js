const s="/static/images/1711946477.bell.svg";export{s as default};
