const t="/static/images/1711946477.bg-pattern-light.svg";export{t as default};
