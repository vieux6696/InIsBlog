const i="/static/images/1711946477.bilibili.svg";export{i as default};
