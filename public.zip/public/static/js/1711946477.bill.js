const s="/static/images/1711946477.bill.svg";export{s as default};
