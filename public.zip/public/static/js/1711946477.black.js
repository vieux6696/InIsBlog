const a="/static/images/1711946477.black.svg";export{a as default};
