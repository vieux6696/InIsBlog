const t="/static/images/1711946477.book-white.svg";export{t as default};
