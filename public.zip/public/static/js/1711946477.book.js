const s="/static/images/1711946477.book.svg";export{s as default};
