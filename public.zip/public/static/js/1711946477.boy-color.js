const o="/static/images/1711946477.boy-color.svg";export{o as default};
