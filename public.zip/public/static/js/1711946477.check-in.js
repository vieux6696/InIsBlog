const s="/static/images/1711946477.check-in.svg";export{s as default};
