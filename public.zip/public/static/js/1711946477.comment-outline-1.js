const t="/static/images/1711946477.comment-outline-1.svg";export{t as default};
