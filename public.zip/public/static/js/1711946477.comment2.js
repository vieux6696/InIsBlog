const t="/static/images/1711946477.comment.svg";export{t as default};
