const s="/static/images/1711946477.cookie.svg";export{s as default};
