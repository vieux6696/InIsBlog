const t="/static/images/1711946477.crypt.svg";export{t as default};
