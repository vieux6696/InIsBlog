const e="/static/images/1711946477.delete.svg";export{e as default};
