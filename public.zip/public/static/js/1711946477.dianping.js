const a="/static/images/1711946477.dianping.svg";export{a as default};
