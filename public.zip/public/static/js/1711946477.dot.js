const t="/static/images/1711946477.dot.svg";export{t as default};
