const s="/static/images/1711946477.douyin.svg";export{s as default};
