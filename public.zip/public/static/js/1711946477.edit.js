const t="/static/images/1711946477.edit.svg";export{t as default};
