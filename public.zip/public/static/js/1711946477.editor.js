const t="/static/images/1711946477.editor.svg";export{t as default};
