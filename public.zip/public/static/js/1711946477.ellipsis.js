const s="/static/images/1711946477.ellipsis.svg";export{s as default};
