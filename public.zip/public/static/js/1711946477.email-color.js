const a="/static/images/1711946477.email-color.svg";export{a as default};
