const a="/static/images/1711946477.email.svg";export{a as default};
