const s="/static/images/1711946477.emoji-1.svg";export{s as default};
