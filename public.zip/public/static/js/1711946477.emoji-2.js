const s="/static/images/1711946477.emoji-2.svg";export{s as default};
