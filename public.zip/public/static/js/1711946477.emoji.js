const s="/static/images/1711946477.emoji.svg";export{s as default};
