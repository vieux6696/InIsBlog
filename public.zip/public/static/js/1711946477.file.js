const s="/static/images/1711946477.file.svg";export{s as default};
