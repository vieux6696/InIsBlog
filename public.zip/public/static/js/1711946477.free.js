const e="/static/images/1711946477.free.svg";export{e as default};
