const s="/static/images/1711946477.full-screen.svg";export{s as default};
