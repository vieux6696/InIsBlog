const s="/static/images/1711946477.girl-color.svg";export{s as default};
