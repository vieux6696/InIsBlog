const t="/static/images/1711946477.gitee.svg";export{t as default};
