const s="/static/images/1711946477.group.svg";export{s as default};
