const s="/static/images/1711946477.help-icon.svg";export{s as default};
