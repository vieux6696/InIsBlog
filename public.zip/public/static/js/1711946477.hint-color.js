const t="/static/images/1711946477.hint-color.svg";export{t as default};
