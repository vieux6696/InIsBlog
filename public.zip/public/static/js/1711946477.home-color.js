const o="/static/images/1711946477.home-color.svg";export{o as default};
