const t="/static/images/1711946477.hot.svg";export{t as default};
