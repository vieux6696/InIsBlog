const a="/static/images/1711946477.id-card-color.svg";export{a as default};
