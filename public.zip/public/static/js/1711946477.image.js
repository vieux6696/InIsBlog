const a="/static/images/1711946477.image.svg";export{a as default};
