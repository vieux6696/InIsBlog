const s="/static/images/1711946477.key.svg";export{s as default};
