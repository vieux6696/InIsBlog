const t="/static/images/1711946477.left.svg";export{t as default};
