const e="/static/images/1711946477.level.svg";export{e as default};
