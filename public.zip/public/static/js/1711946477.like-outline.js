const t="/static/images/1711946477.like-outline.svg";export{t as default};
