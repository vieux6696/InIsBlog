const s="/static/images/1711946477.like.svg";export{s as default};
