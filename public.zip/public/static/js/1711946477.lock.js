const s="/static/images/1711946477.lock.svg";export{s as default};
