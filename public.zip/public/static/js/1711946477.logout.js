const t="/static/images/1711946477.logout.svg";export{t as default};
