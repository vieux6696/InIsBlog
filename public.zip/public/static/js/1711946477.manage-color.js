const a="/static/images/1711946477.manage-color.svg";export{a as default};
