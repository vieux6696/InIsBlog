const s="/static/images/1711946477.n.svg";export{s as default};
