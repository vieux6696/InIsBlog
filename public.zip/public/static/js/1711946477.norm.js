const s="/static/images/1711946477.norm.svg";export{s as default};
