const s="/static/images/1711946477.offline.svg";export{s as default};
