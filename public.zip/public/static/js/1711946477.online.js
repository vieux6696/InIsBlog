const s="/static/images/1711946477.online.svg";export{s as default};
