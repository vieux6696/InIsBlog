const s="/static/images/1711946477.open.svg";export{s as default};
