const s="/static/images/1711946477.order.svg";export{s as default};
