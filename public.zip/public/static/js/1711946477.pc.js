const s="/static/images/1711946477.pc.svg";export{s as default};
