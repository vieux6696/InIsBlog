const o="/static/images/1711946477.phone-color.svg";export{o as default};
