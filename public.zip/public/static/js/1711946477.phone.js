const s="/static/images/1711946477.phone.svg";export{s as default};
