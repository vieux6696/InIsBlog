const s="/static/images/1711946477.qq.svg";export{s as default};
