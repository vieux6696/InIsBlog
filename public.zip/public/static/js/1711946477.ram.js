const a="/static/images/1711946477.ram.svg";export{a as default};
