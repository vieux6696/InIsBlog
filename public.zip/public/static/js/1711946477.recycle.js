const e="/static/images/1711946477.recycle.svg";export{e as default};
