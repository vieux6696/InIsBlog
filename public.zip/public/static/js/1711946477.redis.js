const s="/static/images/1711946477.redis.svg";export{s as default};
