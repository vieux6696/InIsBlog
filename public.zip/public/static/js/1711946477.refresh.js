const s="/static/images/1711946477.refresh.svg";export{s as default};
