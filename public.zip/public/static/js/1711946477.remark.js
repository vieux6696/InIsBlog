const a="/static/images/1711946477.remark.svg";export{a as default};
