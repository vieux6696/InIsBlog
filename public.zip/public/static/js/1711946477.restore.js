const s="/static/images/1711946477.restore.svg";export{s as default};
