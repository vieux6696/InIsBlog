const t="/static/images/1711946477.right.svg";export{t as default};
