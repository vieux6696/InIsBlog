const a="/static/images/1711946477.safeguard.svg";export{a as default};
