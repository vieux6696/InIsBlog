const s="/static/images/1711946477.security-1.svg";export{s as default};
