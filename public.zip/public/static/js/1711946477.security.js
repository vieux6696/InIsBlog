const s="/static/images/1711946477.security.svg";export{s as default};
