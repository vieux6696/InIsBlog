const s="/static/images/1711946477.serve.svg";export{s as default};
