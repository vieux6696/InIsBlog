const s="/static/images/1711946477.sign-in.svg";export{s as default};
