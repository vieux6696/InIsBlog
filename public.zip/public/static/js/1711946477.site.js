const s="/static/images/1711946477.site.svg";export{s as default};
