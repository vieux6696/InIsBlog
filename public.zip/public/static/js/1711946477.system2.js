const s="/static/images/1711946477.system.svg";export{s as default};
