const s="/static/images/1711946477.task.svg";export{s as default};
