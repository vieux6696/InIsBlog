const t="/static/images/1711946477.theme-color.svg";export{t as default};
