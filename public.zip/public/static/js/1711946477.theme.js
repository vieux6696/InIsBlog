const t="/static/images/1711946477.theme.svg";export{t as default};
