const t="/static/images/1711946477.time.svg";export{t as default};
