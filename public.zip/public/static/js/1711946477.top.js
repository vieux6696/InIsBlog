const t="/static/images/1711946477.top.svg";export{t as default};
