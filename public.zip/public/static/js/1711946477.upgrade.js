const a="/static/images/1711946477.upgrade.svg";export{a as default};
