const a="/static/images/1711946477.upload.svg";export{a as default};
