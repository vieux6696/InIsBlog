const s="/static/images/1711946477.user-agent.svg";export{s as default};
