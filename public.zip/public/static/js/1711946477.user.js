const s="/static/images/1711946477.user.svg";export{s as default};
