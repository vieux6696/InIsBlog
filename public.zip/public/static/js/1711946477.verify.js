const s="/static/images/1711946477.verify.svg";export{s as default};
