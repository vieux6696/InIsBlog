const s="/static/images/1711946477.version.svg";export{s as default};
