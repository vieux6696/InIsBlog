const t="/static/images/1711946477.vip-integral.svg";export{t as default};
