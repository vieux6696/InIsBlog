const s="/static/images/1711946477.visit.svg";export{s as default};
