const s="/static/images/1711946477.vue.svg";export{s as default};
