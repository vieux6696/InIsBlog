const t="/static/images/1711946477.wait.svg";export{t as default};
