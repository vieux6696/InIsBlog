const t="/static/images/1711946477.we-chat.svg";export{t as default};
