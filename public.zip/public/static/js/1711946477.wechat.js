const t="/static/images/1711946477.wechat.svg";export{t as default};
